/**
 * Console API Interceptor
 * Captures console messages and forwards them to the native app
 * Supports all standard console methods with proper formatting
 */

(function() {
  'use strict';

  // Store original console methods
  const originalConsole = {
    log: console.log,
    debug: console.debug,
    info: console.info,
    warn: console.warn,
    error: console.error,
    trace: console.trace,
    table: console.table,
    dir: console.dir,
    dirxml: console.dirxml,
    group: console.group,
    groupCollapsed: console.groupCollapsed,
    groupEnd: console.groupEnd,
    assert: console.assert,
    count: console.count,
    countReset: console.countReset,
    time: console.time,
    timeLog: console.timeLog,
    timeEnd: console.timeEnd,
    clear: console.clear
  };

  // Helper to serialize arguments
  function serializeArgs(args) {
    return Array.from(args).map(arg => {
      if (arg === null) return 'null';
      if (arg === undefined) return 'undefined';
      if (typeof arg === 'object') {
        try {
          return JSON.stringify(arg, null, 2);
        } catch (e) {
          return String(arg);
        }
      }
      return String(arg);
    });
  }

  // Helper to get stack trace
  function getStackTrace() {
    try {
      throw new Error();
    } catch (e) {
      // Remove first 3 lines (Error, getStackTrace, interceptor function)
      const stack = e.stack.split('\n').slice(3).join('\n');
      return stack;
    }
  }

  // Intercept console.log
  console.log = function(...args) {
    originalConsole.log.apply(console, args);
    window.webkit.messageHandlers.consoleMessage.postMessage({
      type: 'log',
      args: serializeArgs(args),
      timestamp: Date.now(),
      url: window.location.href
    });
  };

  // Intercept console.debug
  console.debug = function(...args) {
    originalConsole.debug.apply(console, args);
    window.webkit.messageHandlers.consoleMessage.postMessage({
      type: 'debug',
      args: serializeArgs(args),
      timestamp: Date.now(),
      url: window.location.href
    });
  };

  // Intercept console.info
  console.info = function(...args) {
    originalConsole.info.apply(console, args);
    window.webkit.messageHandlers.consoleMessage.postMessage({
      type: 'info',
      args: serializeArgs(args),
      timestamp: Date.now(),
      url: window.location.href
    });
  };

  // Intercept console.warn
  console.warn = function(...args) {
    originalConsole.warn.apply(console, args);
    window.webkit.messageHandlers.consoleMessage.postMessage({
      type: 'warn',
      args: serializeArgs(args),
      timestamp: Date.now(),
      url: window.location.href
    });
  };

  // Intercept console.error
  console.error = function(...args) {
    originalConsole.error.apply(console, args);
    window.webkit.messageHandlers.consoleMessage.postMessage({
      type: 'error',
      args: serializeArgs(args),
      timestamp: Date.now(),
      url: window.location.href,
      stack: getStackTrace()
    });
  };

  // Intercept console.trace
  console.trace = function(...args) {
    originalConsole.trace.apply(console, args);
    window.webkit.messageHandlers.consoleMessage.postMessage({
      type: 'trace',
      args: serializeArgs(args),
      timestamp: Date.now(),
      url: window.location.href,
      stack: getStackTrace()
    });
  };

  // Intercept console.assert
  console.assert = function(condition, ...args) {
    originalConsole.assert.apply(console, [condition, ...args]);
    if (!condition) {
      window.webkit.messageHandlers.consoleMessage.postMessage({
        type: 'assert',
        args: ['Assertion failed:', ...serializeArgs(args)],
        timestamp: Date.now(),
        url: window.location.href,
        stack: getStackTrace()
      });
    }
  };

  // Intercept console.clear
  console.clear = function() {
    originalConsole.clear.apply(console);
    window.webkit.messageHandlers.consoleMessage.postMessage({
      type: 'clear',
      args: [],
      timestamp: Date.now(),
      url: window.location.href
    });
  };

  // Intercept console.table
  console.table = function(...args) {
    originalConsole.table.apply(console, args);
    window.webkit.messageHandlers.consoleMessage.postMessage({
      type: 'table',
      args: serializeArgs(args),
      timestamp: Date.now(),
      url: window.location.href
    });
  };

  // Intercept console.dir
  console.dir = function(...args) {
    originalConsole.dir.apply(console, args);
    window.webkit.messageHandlers.consoleMessage.postMessage({
      type: 'dir',
      args: serializeArgs(args),
      timestamp: Date.now(),
      url: window.location.href
    });
  };

  // Intercept console.group
  console.group = function(...args) {
    originalConsole.group.apply(console, args);
    window.webkit.messageHandlers.consoleMessage.postMessage({
      type: 'group',
      args: serializeArgs(args),
      timestamp: Date.now(),
      url: window.location.href
    });
  };

  // Intercept console.groupCollapsed
  console.groupCollapsed = function(...args) {
    originalConsole.groupCollapsed.apply(console, args);
    window.webkit.messageHandlers.consoleMessage.postMessage({
      type: 'groupCollapsed',
      args: serializeArgs(args),
      timestamp: Date.now(),
      url: window.location.href
    });
  };

  // Intercept console.groupEnd
  console.groupEnd = function() {
    originalConsole.groupEnd.apply(console);
    window.webkit.messageHandlers.consoleMessage.postMessage({
      type: 'groupEnd',
      args: [],
      timestamp: Date.now(),
      url: window.location.href
    });
  };

  // Count tracking
  const counts = {};
  console.count = function(label = 'default') {
    counts[label] = (counts[label] || 0) + 1;
    const message = `${label}: ${counts[label]}`;
    originalConsole.count.apply(console, [label]);
    window.webkit.messageHandlers.consoleMessage.postMessage({
      type: 'count',
      args: [message],
      timestamp: Date.now(),
      url: window.location.href
    });
  };

  console.countReset = function(label = 'default') {
    counts[label] = 0;
    originalConsole.countReset.apply(console, [label]);
    window.webkit.messageHandlers.consoleMessage.postMessage({
      type: 'countReset',
      args: [label],
      timestamp: Date.now(),
      url: window.location.href
    });
  };

  // Time tracking
  const timers = {};
  console.time = function(label = 'default') {
    timers[label] = Date.now();
    originalConsole.time.apply(console, [label]);
  };

  console.timeLog = function(label = 'default', ...args) {
    if (timers[label]) {
      const elapsed = Date.now() - timers[label];
      originalConsole.timeLog.apply(console, [label, ...args]);
      window.webkit.messageHandlers.consoleMessage.postMessage({
        type: 'timeLog',
        args: [`${label}: ${elapsed}ms`, ...serializeArgs(args)],
        timestamp: Date.now(),
        url: window.location.href
      });
    }
  };

  console.timeEnd = function(label = 'default') {
    if (timers[label]) {
      const elapsed = Date.now() - timers[label];
      delete timers[label];
      originalConsole.timeEnd.apply(console, [label]);
      window.webkit.messageHandlers.consoleMessage.postMessage({
        type: 'timeEnd',
        args: [`${label}: ${elapsed}ms`],
        timestamp: Date.now(),
        url: window.location.href
      });
    }
  };

  // Capture uncaught errors
  window.addEventListener('error', function(event) {
    window.webkit.messageHandlers.consoleMessage.postMessage({
      type: 'error',
      args: [`Uncaught ${event.error?.name || 'Error'}: ${event.message}`],
      timestamp: Date.now(),
      url: window.location.href,
      stack: event.error?.stack || '',
      filename: event.filename,
      lineno: event.lineno,
      colno: event.colno
    });
  });

  // Capture unhandled promise rejections
  window.addEventListener('unhandledrejection', function(event) {
    window.webkit.messageHandlers.consoleMessage.postMessage({
      type: 'error',
      args: [`Unhandled Promise Rejection: ${event.reason}`],
      timestamp: Date.now(),
      url: window.location.href,
      stack: event.reason?.stack || ''
    });
  });

  // Log that interceptor is loaded (only in development)
  if (window.location.hostname === 'localhost' || window.location.hostname === '127.0.0.1') {
    originalConsole.log('✅ Console interceptor loaded');
  }
})();
