/**
 * CSP (Content Security Policy) Violation Monitor
 * Captures CSP violations and reports them to the native app
 */

(function() {
  'use strict';

  // Listen for CSP violations
  document.addEventListener('securitypolicyviolation', function(event) {
    const violation = {
      documentURI: event.documentURI,
      blockedURI: event.blockedURI,
      violatedDirective: event.violatedDirective,
      effectiveDirective: event.effectiveDirective,
      originalPolicy: event.originalPolicy,
      disposition: event.disposition, // 'enforce' or 'report'
      statusCode: event.statusCode,
      lineNumber: event.lineNumber,
      columnNumber: event.columnNumber,
      sourceFile: event.sourceFile,
      sample: event.sample, // Sample of the violating code (if available)
      timestamp: Date.now()
    };

    // Send to native app
    if (window.webkit && window.webkit.messageHandlers && window.webkit.messageHandlers.cspViolation) {
      window.webkit.messageHandlers.cspViolation.postMessage(violation);
    }

    // Also log to console for debugging
    console.warn('[CSP Violation]', violation.violatedDirective, '-', violation.blockedURI);
  });

  // Notify that CSP monitor is active
  if (window.webkit && window.webkit.messageHandlers && window.webkit.messageHandlers.cspViolation) {
    window.webkit.messageHandlers.cspViolation.postMessage({
      type: 'init',
      documentURI: document.location.href,
      timestamp: Date.now()
    });
  }
})();
