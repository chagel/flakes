/**
 * LinkHints.js
 * Vimium-style link hints for keyboard navigation
 *
 * Usage:
 * - Press 'f' to activate link hints
 * - Type hint letters to filter links
 * - Hold Shift while typing to open in new tab
 * - Press Escape to exit
 */

(function() {
  'use strict';

  let isActive = false;
  let hints = [];
  let hintElements = [];
  let currentInput = '';
  const hintChars = 'asdfghjklqwertyuiopzxcvbnm';

  // Inject styles
  const style = document.createElement('style');
  style.id = 'flakes-link-hints-style';
  style.textContent = `
    .flakes-hint-overlay {
      position: absolute;
      background: #FFD700;
      color: #000;
      font-family: -apple-system, system-ui, monospace;
      font-size: 10px;
      font-weight: bold;
      padding: 2px 4px;
      border-radius: 2px;
      z-index: 999999;
      pointer-events: none;
      box-shadow: 0 0 0 1px rgba(0,0,0,0.3), 0 2px 4px rgba(0,0,0,0.4);
      text-transform: uppercase;
    }
    .flakes-hint-overlay.matched {
      background: #90EE90;
    }
    .flakes-click-effect {
      position: absolute;
      background: rgba(26, 115, 232, 0.3);
      border: 2px solid #1A73E8;
      border-radius: 4px;
      pointer-events: none;
      z-index: 999998;
      animation: flakes-flash 0.3s ease-out;
    }
    @keyframes flakes-flash {
      0% { opacity: 1; transform: scale(1); }
      100% { opacity: 0; transform: scale(1.1); }
    }
  `;

  /**
   * Generate prefix-free hint labels
   * Ensures no hint is a prefix of another (e.g., avoid 'a' and 'aa')
   */
  function generateHints(count) {
    if (count === 0) return [];
    if (count === 1) return [hintChars[0]];

    // Calculate optimal hint length
    const base = hintChars.length;
    let hintLength = Math.ceil(Math.log(count) / Math.log(base));

    // For small counts, use single characters
    if (count <= base) {
      return Array.from({ length: count }, (_, i) => hintChars[i]);
    }

    // Generate hints of uniform length (prefix-free by design)
    const hints = [];
    let index = 0;

    while (hints.length < count) {
      let hint = '';
      let num = index;

      for (let i = 0; i < hintLength; i++) {
        hint = hintChars[num % base] + hint;
        num = Math.floor(num / base);
      }

      hints.push(hint);
      index++;
    }

    return hints;
  }

  /**
   * Show visual click effect at element position
   */
  function showClickEffect(element) {
    const rect = element.getBoundingClientRect();
    const effect = document.createElement('div');
    effect.className = 'flakes-click-effect';
    effect.style.left = (rect.left + window.scrollX) + 'px';
    effect.style.top = (rect.top + window.scrollY) + 'px';
    effect.style.width = rect.width + 'px';
    effect.style.height = rect.height + 'px';
    document.body.appendChild(effect);

    // Remove after animation completes
    setTimeout(() => effect.remove(), 300);
  }

  /**
   * Activate link hints mode
   */
  function activateLinkHints() {
    if (isActive) return;
    isActive = true;
    currentInput = '';

    // Add styles if not already present
    if (!document.getElementById('flakes-link-hints-style')) {
      document.head.appendChild(style);
    }

    // Find all clickable elements
    const clickables = Array.from(
      document.querySelectorAll('a[href], button, input[type="submit"], input[type="button"], [role="button"], [onclick]')
    ).filter(el => {
      const rect = el.getBoundingClientRect();
      return rect.width > 0 && rect.height > 0 &&
             rect.top < window.innerHeight && rect.bottom > 0 &&
             rect.left < window.innerWidth && rect.right > 0;
    });

    hintElements = clickables;
    const hintLabels = generateHints(clickables.length);

    clickables.forEach((el, index) => {
      const rect = el.getBoundingClientRect();
      const hint = document.createElement('div');
      hint.className = 'flakes-hint-overlay';
      hint.textContent = hintLabels[index];
      hint.style.left = (rect.left + window.scrollX) + 'px';
      hint.style.top = (rect.top + window.scrollY) + 'px';
      document.body.appendChild(hint);

      hints.push({ element: el, label: hintLabels[index], overlay: hint });
    });

    window.webkit.messageHandlers.linkHintsMode.postMessage({ active: true });
  }

  /**
   * Deactivate link hints mode
   */
  function deactivateLinkHints() {
    if (!isActive) return;
    isActive = false;
    currentInput = '';

    hints.forEach(({ overlay }) => {
      overlay.remove();
    });
    hints = [];
    hintElements = [];

    window.webkit.messageHandlers.linkHintsMode.postMessage({ active: false });
  }

  /**
   * Handle hint key input
   * @param {string} key - The key pressed
   * @param {boolean} shift - Whether Shift was held
   */
  function handleHintInput(key, shift = false) {
    if (!isActive) return;

    currentInput += key.toLowerCase();

    // Filter matching hints
    const matchingHints = hints.filter(h => h.label.startsWith(currentInput));

    if (matchingHints.length === 0) {
      // No match - reset
      deactivateLinkHints();
      return;
    }

    if (matchingHints.length === 1 && matchingHints[0].label === currentInput) {
      // Exact match - activate link
      const target = matchingHints[0].element;
      const openInNewTab = shift;

      // Show click effect
      showClickEffect(target);

      // Deactivate hints
      deactivateLinkHints();

      // Activate after brief delay for visual feedback
      setTimeout(() => {
        if (target.tagName === 'A') {
          if (openInNewTab) {
            // Open in new tab
            window.open(target.href, '_blank');
          } else {
            // Navigate in current tab
            window.location.href = target.href;
          }
        } else {
          // For buttons, trigger click
          target.click();
        }
      }, 100);
      return;
    }

    // Update visual feedback
    hints.forEach(({ label, overlay }) => {
      if (label.startsWith(currentInput)) {
        overlay.classList.add('matched');
        // Show remaining characters
        overlay.textContent = label.substring(currentInput.length);
      } else {
        overlay.style.display = 'none';
      }
    });
  }

  // Expose API to native code
  window.flakesLinkHints = {
    activate: activateLinkHints,
    deactivate: deactivateLinkHints,
    handleInput: handleHintInput,
    isActive: () => isActive
  };
})();
