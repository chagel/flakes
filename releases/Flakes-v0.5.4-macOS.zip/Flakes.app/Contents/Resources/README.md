# WebExtensions

This directory contains JavaScript files that are injected into web pages, organized by feature like browser extensions.

## Structure

Each feature is in its own JavaScript file:

- **`LinkHints.js`** - Vimium-style keyboard link navigation
- **`ShiftClick.js`** - Shift+Click to open links in new tab

## Adding New Extensions

1. **Create the JavaScript file** in this directory:
   ```javascript
   /**
    * FeatureName.js
    * Brief description
    */

   (function() {
     'use strict';

     // Your feature code here

     // Expose API if needed
     window.flakesFeatureName = {
       // API methods
     };
   })();
   ```

2. **Add to ScriptLoader** in `WebViewController.swift`:
   ```swift
   let scripts = [
     ("ShiftClick", .atDocumentEnd, false),
     ("LinkHints", .atDocumentEnd, false),
     ("YourFeature", .atDocumentEnd, false) // Add here
   ]
   ```

3. **Communicate with Swift** using message handlers:
   ```javascript
   window.webkit.messageHandlers.yourHandler.postMessage(data);
   ```

4. **Register handler** in `WebViewController.swift`:
   ```swift
   configuration.userContentController.add(LeakAvoider(delegate: self), name: "yourHandler")
   ```

## Best Practices

- **One feature per file** - Keep scripts focused and maintainable
- **IIFE wrapper** - Wrap code in `(function() { ... })()` to avoid global pollution
- **Strict mode** - Always use `'use strict';` at the top
- **Error handling** - Handle errors gracefully
- **Documentation** - Include clear comments explaining the feature
- **Namespacing** - Use `window.flakes*` prefix for exposed APIs

## Injection Timing

- **`.atDocumentStart`** - Before page loads (for early modifications)
- **`.atDocumentEnd`** - After DOM is ready (most common)

## Current Features

### LinkHints.js
Keyboard navigation for links:
- Press `f` to activate
- Type hint letters to select link
- Hold Shift to open in new tab
- Visual click effect on activation

**API:**
```javascript
window.flakesLinkHints.activate()
window.flakesLinkHints.deactivate()
window.flakesLinkHints.handleInput(key, shift)
window.flakesLinkHints.isActive()
```

### ShiftClick.js
Simple Shift+Click handler:
- Shift+Click any link to open in new tab
- No API exposed (event listener only)
