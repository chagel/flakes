/**
 * ShiftClick.js
 * Handles Shift+Click on links to open in new tab
 *
 * Usage:
 * - Shift+Click any link to open it in a new tab
 * - Works on any <a> element with an href attribute
 */

(function() {
  'use strict';

  /**
   * Handle click events with Shift modifier
   */
  document.addEventListener('click', function(e) {
    // Only process if Shift key is pressed
    if (!e.shiftKey) return;

    // Find the closest <a> tag
    let target = e.target;
    while (target && target.tagName !== 'A') {
      target = target.parentElement;
    }

    // If we found a link with href
    if (target && target.href) {
      e.preventDefault();

      // Notify native code to open in new tab
      window.webkit.messageHandlers.shiftClick.postMessage({
        url: target.href
      });
    }
  }, true); // Use capture phase to catch events early

})();
