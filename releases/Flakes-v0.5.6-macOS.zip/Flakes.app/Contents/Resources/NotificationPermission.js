/**
 * Notification Permission Handler
 * Intercepts Notification.requestPermission() and routes through native permission system
 */

(function() {
  'use strict';

  // Store original Notification constructor
  const OriginalNotification = window.Notification;

  // Override Notification.requestPermission
  if (OriginalNotification) {
    const originalRequestPermission = OriginalNotification.requestPermission;

    OriginalNotification.requestPermission = function(callback) {
      return new Promise((resolve) => {
        // Request permission through native handler
        if (window.webkit && window.webkit.messageHandlers && window.webkit.messageHandlers.notificationPermission) {
          window.webkit.messageHandlers.notificationPermission.postMessage({
            type: 'request',
            host: window.location.hostname
          });

          // Store callback for when native responds
          window.__flakesNotificationCallback = function(permission) {
            if (callback) callback(permission);
            resolve(permission);
          };
        } else {
          // Fallback to original if no handler
          if (originalRequestPermission) {
            originalRequestPermission.call(OriginalNotification, callback).then(resolve);
          } else {
            resolve('denied');
          }
        }
      });
    };

    // Override permission getter
    Object.defineProperty(OriginalNotification, 'permission', {
      get: function() {
        // Check with native for current permission state
        // For now, return 'default' to trigger requestPermission flow
        return window.__flakesNotificationPermission || 'default';
      }
    });
  }

  // Function called by native to set permission result
  window.flakesSetNotificationPermission = function(permission) {
    window.__flakesNotificationPermission = permission;
    if (window.__flakesNotificationCallback) {
      window.__flakesNotificationCallback(permission);
      delete window.__flakesNotificationCallback;
    }
  };
})();
