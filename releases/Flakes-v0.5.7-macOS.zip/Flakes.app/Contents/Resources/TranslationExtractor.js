// TranslationExtractor.js
// Extracts translatable text nodes from DOM and replaces them with translations
// while preserving all HTML structure, CSS, and JavaScript functionality

(function() {
  'use strict';

  class TranslationExtractor {
    constructor() {
      this.textNodes = [];
      this.attributes = [];
    }

    /**
     * Extract all translatable content from the page
     * @returns {Object} Contains textNodes, attributes, and metadata
     */
    extract() {
      this.textNodes = [];
      this.attributes = [];

      this.extractTextNodes(document.body);
      this.extractAttributes();

      return {
        textNodes: this.textNodes,
        attributes: this.attributes,
        metadata: {
          totalNodes: this.textNodes.length,
          totalAttributes: this.attributes.length,
          url: window.location.href,
          title: document.title,
          lang: document.documentElement.lang || 'unknown'
        }
      };
    }

    /**
     * Extract all visible text nodes using TreeWalker
     * @param {Node} root - Root node to start extraction from
     */
    extractTextNodes(root) {
      const walker = document.createTreeWalker(
        root,
        NodeFilter.SHOW_TEXT,
        {
          acceptNode: (node) => {
            const parent = node.parentElement;
            if (!parent) return NodeFilter.FILTER_REJECT;

            // Skip non-visible elements
            const tagName = parent.tagName.toLowerCase();
            if (['script', 'style', 'noscript'].includes(tagName)) {
              return NodeFilter.FILTER_REJECT;
            }

            // Skip code blocks (preserve code as-is)
            if (['code', 'pre'].includes(tagName)) {
              return NodeFilter.FILTER_REJECT;
            }

            // Skip empty or whitespace-only text
            const text = node.textContent.trim();
            if (text.length === 0) return NodeFilter.FILTER_REJECT;

            // Skip hidden elements
            const style = window.getComputedStyle(parent);
            if (style.display === 'none' || style.visibility === 'hidden') {
              return NodeFilter.FILTER_REJECT;
            }

            return NodeFilter.FILTER_ACCEPT;
          }
        }
      );

      let nodeId = 0;
      let currentNode;

      while (currentNode = walker.nextNode()) {
        const id = `text-${nodeId++}`;

        // Store ID on the node itself for later replacement
        currentNode.__translationId = id;

        this.textNodes.push({
          id: id,
          text: currentNode.textContent.trim(),
          parentTag: currentNode.parentElement.tagName.toLowerCase(),
          context: this.getContext(currentNode)
        });
      }
    }

    /**
     * Extract translatable attributes (alt, placeholder, title)
     */
    extractAttributes() {
      // Extract alt attributes from images
      document.querySelectorAll('img[alt]').forEach((img, idx) => {
        const altText = img.getAttribute('alt');
        if (altText && altText.trim()) {
          const id = `alt-${idx}`;
          img.__altId = id;
          this.attributes.push({
            id: id,
            type: 'alt',
            text: altText,
            element: 'img'
          });
        }
      });

      // Extract placeholder attributes
      document.querySelectorAll('input[placeholder], textarea[placeholder]').forEach((el, idx) => {
        const placeholder = el.getAttribute('placeholder');
        if (placeholder && placeholder.trim()) {
          const id = `placeholder-${idx}`;
          el.__placeholderId = id;
          this.attributes.push({
            id: id,
            type: 'placeholder',
            text: placeholder,
            element: el.tagName.toLowerCase()
          });
        }
      });

      // Extract title attributes (tooltips)
      document.querySelectorAll('[title]').forEach((el, idx) => {
        const title = el.getAttribute('title');
        if (title && title.trim()) {
          const id = `title-${idx}`;
          el.__titleId = id;
          this.attributes.push({
            id: id,
            type: 'title',
            text: title,
            element: el.tagName.toLowerCase()
          });
        }
      });
    }

    /**
     * Get contextual information for better translation accuracy
     * @param {Node} node - Text node to get context for
     * @returns {Object} Context information
     */
    getContext(node) {
      const parent = node.parentElement;

      // Find nearest heading for context
      let heading = null;
      let current = parent;
      let depth = 0;

      while (current && !heading && depth < 10) {
        // Check previous siblings for headings
        let sibling = current.previousElementSibling;
        while (sibling && !heading) {
          if (/^h[1-6]$/i.test(sibling.tagName)) {
            heading = sibling.textContent.trim();
            break;
          }
          sibling = sibling.previousElementSibling;
        }

        // Move up the tree
        current = current.parentElement;
        depth++;
      }

      return {
        heading: heading,
        parentClass: parent.className || null,
        parentId: parent.id || null
      };
    }

    /**
     * Replace text nodes and attributes with translations
     * @param {Object} translations - Contains textNodes and attributes arrays
     * @returns {number} Number of nodes replaced
     */
    replace(translations) {
      let replaced = 0;

      // Build maps for fast lookup
      const textMap = new Map(
        (translations.textNodes || []).map(t => [t.id, t.translation])
      );

      const attrMap = new Map(
        (translations.attributes || []).map(a => [a.id, a.translation])
      );

      // Replace text nodes
      const walker = document.createTreeWalker(
        document.body,
        NodeFilter.SHOW_TEXT,
        null
      );

      let currentNode;
      while (currentNode = walker.nextNode()) {
        const id = currentNode.__translationId;
        if (id && textMap.has(id)) {
          // Preserve leading/trailing whitespace
          const original = currentNode.textContent;
          const leadingSpace = original.match(/^\s*/)[0];
          const trailingSpace = original.match(/\s*$/)[0];
          const translated = textMap.get(id);

          currentNode.textContent = leadingSpace + translated + trailingSpace;
          replaced++;
        }
      }

      // Replace attributes
      this.replaceAttributes(attrMap);

      return replaced;
    }

    /**
     * Replace attribute translations
     * @param {Map} attrMap - Map of attribute IDs to translations
     */
    replaceAttributes(attrMap) {
      // Replace alt attributes
      document.querySelectorAll('img').forEach(img => {
        const id = img.__altId;
        if (id && attrMap.has(id)) {
          img.setAttribute('alt', attrMap.get(id));
        }
      });

      // Replace placeholder attributes
      document.querySelectorAll('input, textarea').forEach(el => {
        const id = el.__placeholderId;
        if (id && attrMap.has(id)) {
          el.setAttribute('placeholder', attrMap.get(id));
        }
      });

      // Replace title attributes
      document.querySelectorAll('[title]').forEach(el => {
        const id = el.__titleId;
        if (id && attrMap.has(id)) {
          el.setAttribute('title', attrMap.get(id));
        }
      });
    }
  }

  // Expose API to native Swift code
  window.flakesTranslation = {
    /**
     * Extract all translatable content
     * @returns {Object} Extraction result with textNodes, attributes, metadata
     */
    extract: function() {
      const extractor = new TranslationExtractor();
      return extractor.extract();
    },

    /**
     * Replace content with translations
     * @param {Object} translations - Object with textNodes and attributes arrays
     * @returns {number} Number of nodes replaced
     */
    replace: function(translations) {
      const extractor = new TranslationExtractor();
      return extractor.replace(translations);
    }
  };
})();
