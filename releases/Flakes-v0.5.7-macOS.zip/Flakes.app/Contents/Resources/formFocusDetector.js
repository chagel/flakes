/**
 * Form Focus Detector
 * Automatically detects when text input fields are focused/blurred
 * and sends messages to the app to switch between Insert/View modes
 */

(function() {
  'use strict';

  // Check if an element is a text input field
  function isTextInput(element) {
    if (!element) return false;

    const tagName = element.tagName.toLowerCase();

    // Textarea is always a text input
    if (tagName === 'textarea') return true;

    // Input elements - check type
    if (tagName === 'input') {
      const type = (element.type || 'text').toLowerCase();
      // Text input types
      const textInputTypes = ['text', 'email', 'password', 'search', 'tel', 'url', 'number', 'date', 'datetime-local', 'month', 'time', 'week'];
      return textInputTypes.includes(type);
    }

    // ContentEditable elements
    if (element.isContentEditable) return true;

    return false;
  }

  // Track the currently focused element
  let currentlyFocused = null;

  // Handle focus events
  document.addEventListener('focusin', function(event) {
    const element = event.target;

    if (isTextInput(element)) {
      currentlyFocused = element;
      // Send message to app to enter Insert mode
      window.webkit.messageHandlers.formFocus.postMessage({
        type: 'focus',
        tagName: element.tagName.toLowerCase(),
        inputType: element.type || 'text'
      });
    }
  }, true); // Use capture phase

  // Handle blur events
  document.addEventListener('focusout', function(event) {
    const element = event.target;

    if (isTextInput(element) && currentlyFocused === element) {
      currentlyFocused = null;
      // Send message to app to enter View mode
      window.webkit.messageHandlers.formFocus.postMessage({
        type: 'blur',
        tagName: element.tagName.toLowerCase(),
        inputType: element.type || 'text'
      });
    }
  }, true); // Use capture phase

  // Handle keyboard events to check if we should stay in insert mode
  // (for example, when clicking away from a text field)
  document.addEventListener('click', function(event) {
    const element = event.target;

    // If clicking on a non-text-input element while a text input is focused
    if (currentlyFocused && !isTextInput(element)) {
      // The blur event will handle the mode switch
      // But we can force blur if needed
      if (document.activeElement === currentlyFocused) {
        // Let the browser's natural blur handling work
      }
    }
  }, true);
})();
