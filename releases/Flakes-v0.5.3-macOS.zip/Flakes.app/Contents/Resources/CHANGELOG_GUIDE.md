# Changelog Resources

## Editing the Changelog

The changelog is stored in `changelog.json` for easy editing without touching code.

### File Format

```json
[
  {
    "version": "0.3.3",
    "date": "Nov 19, 2025",
    "items": [
      {
        "type": "feature",
        "description": "Description of the new feature"
      },
      {
        "type": "fix",
        "description": "Description of the bug fix"
      },
      {
        "type": "enhancement",
        "description": "Description of the enhancement"
      }
    ]
  }
]
```

### Item Types

- **`feature`**: New features (displays as "New")
- **`fix`**: Bug fixes (displays as "Fix")
- **`enhancement`**: Improvements to existing features (displays as "Enhanced")

### Adding a New Version

1. Open `changelog.json`
2. Add a new entry at the **top** of the array (most recent first)
3. Update version number and date
4. Add items with type and description
5. Save the file
6. Rebuild the app

### Example: Adding Version 0.3.4

```json
[
  {
    "version": "0.3.4",
    "date": "Nov 20, 2025",
    "items": [
      {
        "type": "feature",
        "description": "New awesome feature"
      }
    ]
  },
  {
    "version": "0.3.3",
    "date": "Nov 19, 2025",
    ...
  }
]
```

### Notes

- The home view displays the **3 most recent** versions by default
- The changelog auto-shows on first launch, then hides after user dismisses it
- Users can toggle the changelog by clicking the version number
